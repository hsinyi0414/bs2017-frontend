# JavaScript, HTML, DOM 綜合題

>
> 請完成正常練習後仍有餘力的同學再進行挑戰
>

## 故事背景

時間 2003 年，小 d 被前公司徵招到台北市某交通 BOT 公司進行專案支援，專案已經火燒屁股距離上線只有一週時間，而 PM 給主角打開了數張魔王卡 ...  

該專案架構完全以靜態 HTML 為前端主體，以 AJAX 搭配後端 API 進行資料的取得與寫入。以資料取得為例，API 回傳一個大型資料集，為了高效率的傳輸，一次傳輸可以包含數個表格，整個資料集使用字串格式呈現，格式規範如下：

- 每一組資料 (table) 後方帶一個 ASCII code = 4 的字元 (\x04)
- 每一個資料列 (row) 後方帶一個 ASCII code = 2 的字元 (\x02)
- 每一個資料格 (cell) 後方帶一個 ASCII code = 1 的字元 (\x01)

原始資料長相如下：

```JavaScript
var str = "Column1\x01Column2\x01Column3\x01Column4\x01Column5\x01Column6\x01Column7\x01Column8\x01Column9\x01Column10\x01\x02Row1_Column1\x01Row1_Column2\x01Row1_Column3\x01Row1_Column4\x01Row1_Column5\x01Row1_Column6\x01Row1_Column7\x01Row1_Column8\x01Row1_Column9\x01Row1_Column10\x01\x02Row2_Column1\x01Row2_Column2\x01Row2_Column3\x01Row2_Column4\x01Row2_Column5\x01Row2_Column6\x01Row2_Column7\x01Row2_Column8\x01Row2_Column9\x01Row2_Column10\x01\x02Row3_Column1\x01Row3_Column2\x01Row3_Column3\x01Row3_Column4\x01Row3_Column5\x01Row3_Column6\x01Row3_Column7\x01Row3_Column8\x01Row3_Column9\x01Row3_Column10\x01\x02Row4_Column1\x01Row4_Column2\x01Row4_Column3\x01Row4_Column4\x01Row4_Column5\x01Row4_Column6\x01Row4_Column7\x01Row4_Column8\x01Row4_Column9\x01Row4_Column10\x01\x02Row5_Column1\x01Row5_Column2\x01Row5_Column3\x01Row5_Column4\x01Row5_Column5\x01Row5_Column6\x01Row5_Column7\x01Row5_Column8\x01Row5_Column9\x01Row5_Column10\x01\x02Row6_Column1\x01Row6_Column2\x01Row6_Column3\x01Row6_Column4\x01Row6_Column5\x01Row6_Column6\x01Row6_Column7\x01Row6_Column8\x01Row6_Column9\x01Row6_Column10\x01\x02Row7_Column1\x01Row7_Column2\x01Row7_Column3\x01Row7_Column4\x01Row7_Column5\x01Row7_Column6\x01Row7_Column7\x01Row7_Column8\x01Row7_Column9\x01Row7_Column10\x01\x02Row8_Column1\x01Row8_Column2\x01Row8_Column3\x01Row8_Column4\x01Row8_Column5\x01Row8_Column6\x01Row8_Column7\x01Row8_Column8\x01Row8_Column9\x01Row8_Column10\x01\x02Row9_Column1\x01Row9_Column2\x01Row9_Column3\x01Row9_Column4\x01Row9_Column5\x01Row9_Column6\x01Row9_Column7\x01Row9_Column8\x01Row9_Column9\x01Row9_Column10\x01\x02Row10_Column1\x01Row10_Column2\x01Row10_Column3\x01Row10_Column4\x01Row10_Column5\x01Row10_Column6\x01Row10_Column7\x01Row10_Column8\x01Row10_Column9\x01Row10_Column10\x01\x02Row11_Column1\x01Row11_Column2\x01Row11_Column3\x01Row11_Column4\x01Row11_Column5\x01Row11_Column6\x01Row11_Column7\x01Row11_Column8\x01Row11_Column9\x01Row11_Column10\x01\x02Row12_Column1\x01Row12_Column2\x01Row12_Column3\x01Row12_Column4\x01Row12_Column5\x01Row12_Column6\x01Row12_Column7\x01Row12_Column8\x01Row12_Column9\x01Row12_Column10\x01\x02Row13_Column1\x01Row13_Column2\x01Row13_Column3\x01Row13_Column4\x01Row13_Column5\x01Row13_Column6\x01Row13_Column7\x01Row13_Column8\x01Row13_Column9\x01Row13_Column10\x01\x02Row14_Column1\x01Row14_Column2\x01Row14_Column3\x01Row14_Column4\x01Row14_Column5\x01Row14_Column6\x01Row14_Column7\x01Row14_Column8\x01Row14_Column9\x01Row14_Column10\x01\x02Row15_Column1\x01Row15_Column2\x01Row15_Column3\x01Row15_Column4\x01Row15_Column5\x01Row15_Column6\x01Row15_Column7\x01Row15_Column8\x01Row15_Column9\x01Row15_Column10\x01\x02Row16_Column1\x01Row16_Column2\x01Row16_Column3\x01Row16_Column4\x01Row16_Column5\x01Row16_Column6\x01Row16_Column7\x01Row16_Column8\x01Row16_Column9\x01Row16_Column10\x01\x02Row17_Column1\x01Row17_Column2\x01Row17_Column3\x01Row17_Column4\x01Row17_Column5\x01Row17_Column6\x01Row17_Column7\x01Row17_Column8\x01Row17_Column9\x01Row17_Column10\x01\x02Row18_Column1\x01Row18_Column2\x01Row18_Column3\x01Row18_Column4\x01Row18_Column5\x01Row18_Column6\x01Row18_Column7\x01Row18_Column8\x01Row18_Column9\x01Row18_Column10\x01\x02Row19_Column1\x01Row19_Column2\x01Row19_Column3\x01Row19_Column4\x01Row19_Column5\x01Row19_Column6\x01Row19_Column7\x01Row19_Column8\x01Row19_Column9\x01Row19_Column10\x01\x02Row20_Column1\x01Row20_Column2\x01Row20_Column3\x01Row20_Column4\x01Row20_Column5\x01Row20_Column6\x01Row20_Column7\x01Row20_Column8\x01Row20_Column9\x01Row20_Column10\x01\x02\x04";
```

因為是前公司，主角對這個開發長久使用的格式也早就習慣了，不覺得稀奇，使用公司提供的慣用程式庫即可解決，直到主角的膝蓋中了一劍 ...  

傳回的資料列達數萬筆！使用公司程式庫將資料轉為 HTML 表格效能奇差無比 (請考慮 2003 年的電腦等級以及當年 IE6 的效能)，於是 ...  

- 甲方：這個網頁載入資料怎麼這麼慢，我們不能驗收，請在上線前搞定
- 前公司技術長：小 d 加油，待會搞定一起去吃宵夜 (菸
- 主角：... (自立自強吧

## 進入主題

我們的目的只是將上述資料變成如下 HTML 表格顯示在頁面上即可：  

```HTML
<table>
    <tr><td>Column1</td><td>Column2</td> ... </tr>
    <tr><td>Row1_Column1</td><td>Row1_Column2</td> ... </tr>
    ...
</table>
```

有沒有比新增 DOM 方法 (.appendChild) 更快的表格呈現方式呢？  

提示：可利用 .innerHTML 以及 Regular Expression

## 解題環境

JavaScript sample code 中的 large-dataset.challenge.html (冬天宿舍很冷時你可以讓電腦多跑幾次這隻 HTML)

## 從中可學習到

- 不要死記招式
- .innerHTML  
  _______________
- .appendChild()  
  _______________
- _______________
- _______________
- _______________
- _______________
